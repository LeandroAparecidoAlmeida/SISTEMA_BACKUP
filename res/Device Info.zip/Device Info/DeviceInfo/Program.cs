﻿using System;
using System.Management;
using System.IO;
using System.Collections.Generic;

namespace DrivesInfo {

    class Program {

        private static string GetDeviceID(String drive) {
            foreach (ManagementObject device in new ManagementObjectSearcher(@"SELECT * FROM Win32_DiskDrive").Get()) {
                string cmd1 = "ASSOCIATORS OF {Win32_DiskDrive.DeviceID='" + device.Properties["DeviceID"].Value +
                "'} WHERE AssocClass = Win32_DiskDriveToDiskPartition";
                foreach (ManagementObject partition in new ManagementObjectSearcher(cmd1).Get()) {
                    string cmd2 = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='" + partition["DeviceID"] +
                    "'} WHERE AssocClass = Win32_LogicalDiskToPartition";
                    foreach (ManagementObject disk in new ManagementObjectSearcher(cmd2).Get()) {
                        if (drive.Equals((string)disk["Name"])) {
                            return (string)device.GetPropertyValue("DeviceID");
                        }
                    }
                }
            }
            return null;
        }

        static void Main(string[] args) {
            String systemDrive = System.Environment.SystemDirectory.Substring(0, 2);
            String deviceID = GetDeviceID(systemDrive);
            foreach (ManagementObject device in new ManagementObjectSearcher(@"SELECT * FROM Win32_DiskDrive").Get()) {
                string cmd1 = "ASSOCIATORS OF {Win32_DiskDrive.DeviceID='" + device.Properties["DeviceID"].Value +
                "'} WHERE AssocClass = Win32_DiskDriveToDiskPartition";
                foreach (ManagementObject partition in new ManagementObjectSearcher(cmd1).Get()) {
                    string cmd2 = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='" + partition["DeviceID"] +
                    "'} WHERE AssocClass = Win32_LogicalDiskToPartition";
                    foreach (ManagementObject disk in new ManagementObjectSearcher(cmd2).Get()) {
                        if (((string)device.GetPropertyValue("DeviceID")).Equals(deviceID)) {
                            Console.WriteLine((string)disk["Name"]);
                        }
                    }
                }
            }
            System.Environment.Exit(0);                      
        }

    }

}
